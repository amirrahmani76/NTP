
extern l_fp	convertRefIDToLFP(uint32_t r);
extern uint32_t	convertLFPToRefID(l_fp num);
